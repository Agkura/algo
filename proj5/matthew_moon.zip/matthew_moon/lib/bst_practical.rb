
def kth_largest(tree_node, k)
  #in order traversal
  # get -k
  # nlogn
end
